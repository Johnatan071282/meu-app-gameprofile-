const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
    if (request.method !== "POST") return json({ error: "Use POST." }, 405);
    if (!env.GEMINI_API_KEY) return json({ error: "A chave da IA ainda não foi configurada pelo administrador." }, 503);

    let body;
    try { body = await request.json(); } catch { return json({ error: "JSON inválido." }, 400); }
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (!prompt || prompt.length > 7000) return json({ error: "Prompt vazio ou muito longo." }, 400);

    try {
      const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(env.GEMINI_API_KEY);
      const upstream = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: "Você é o assistente do aplicativo Game Profile 30. Responda em português do Brasil, com orientações seguras, úteis e práticas para criadores de conteúdo de games.\n\n" + prompt }] }],
          generationConfig: { temperature: 0.8, maxOutputTokens: 1200 }
        })
      });
      const result = await upstream.json();
      if (!upstream.ok) return json({ error: result.error?.message || "A API Gemini recusou a solicitação." }, upstream.status);
      const text = result.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
      if (!text) return json({ error: "A IA não retornou conteúdo. Tente novamente." }, 502);
      return json({ text });
    } catch {
      return json({ error: "Falha ao conectar com o serviço de IA." }, 502);
    }
  }
};
