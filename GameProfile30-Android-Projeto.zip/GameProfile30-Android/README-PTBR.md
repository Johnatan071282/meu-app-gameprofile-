# Game Profile 30 — Android

Projeto inicial para transformar o HTML original em APK Android usando Capacitor e GitHub Actions.

## O que já foi adaptado
- HTML original empacotado como aplicativo Android via Capacitor.
- Mantidas as funcionalidades e o armazenamento local do HTML original.
- Removida a dependência da API `window.claude`.
- Criado um endpoint separado (Cloudflare Worker) para usar Gemini sem colocar a chave secreta dentro do APK.
- Workflow do GitHub Actions para gerar APK de depuração automaticamente.

## Gerar o APK grátis pelo GitHub
1. Crie uma conta em https://github.com/ e um repositório público chamado `game-profile-30`.
2. Envie todos os arquivos desta pasta para a raiz do repositório (incluindo `.github`).
3. Abra a aba **Actions** do repositório e habilite Actions, se solicitado.
4. Selecione **Build Game Profile 30 APK** e clique em **Run workflow**.
5. Aguarde o processo ficar verde. Abra a execução e baixe o artefato **Game-Profile-30-APK**.
6. Extraia o ZIP e instale `app-debug.apk` no Android. O Android poderá pedir autorização para instalar apps desta origem.

O APK `debug` serve para testes e distribuição direta limitada. Para distribuição pública mais profissional, gere um APK/AAB de release assinado e mantenha a chave de assinatura em local seguro. Não publique um APK debug como versão definitiva.

## Configurar IA gratuita (Gemini)
A disponibilidade e os limites gratuitos dependem da conta, região e política vigente do Google. Pode haver limites de requisições e mudanças de preço.

1. Consulte https://aistudio.google.com/app/apikey e crie uma chave Gemini.
2. Crie uma conta gratuita em https://dash.cloudflare.com/.
3. Instale Node.js e Wrangler em um computador: `npm install -g wrangler`.
4. Entre na Cloudflare: `npx wrangler login`.
5. Dentro da pasta `worker`, publique: `npx wrangler deploy`.
6. Cadastre a chave sem colocá-la no código: `npx wrangler secret put GEMINI_API_KEY` e cole a chave quando solicitado.
7. Copie a URL `https://game-profile-30-ai.<seu-subdominio>.workers.dev` que o deploy informar.
8. Cole essa URL em `www/config.js`, dentro das aspas de `GAME_PROFILE_AI_URL`.
9. Envie a alteração ao GitHub e execute novamente o workflow para gerar APK com IA conectada.

**Importante:** o Worker protege a chave da API, mas este exemplo ainda não implementa autenticação de usuário nem proteção robusta contra abuso. Antes de divulgar amplamente, configure limites/monitoramento de uso na Cloudflare e no Google AI Studio. Não prometa IA ilimitada.

## Limitações atuais
- O progresso continua salvo localmente no aparelho/navegador; não há sincronização entre dispositivos nem conta de usuário.
- O app precisa de internet para gerar conteúdo com IA.
- A IA não funcionará até configurar o Worker e a URL em `config.js`.
- O APK gerado pelo workflow é de depuração, não um pacote assinado de lançamento para Play Store.
